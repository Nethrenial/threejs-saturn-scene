Hey Dudes,

In Feb 2005 we had a little comp on the 3D Game Resources to skin a spaceship model I knocked up with the plan to zip em all up after the comp and give em away for free!! Well here it is...

IDOLKNIGHT Won the comp with KRULSPELD coming in a close 2nd, again closely followed by KAOS KIWI who came in 3rd...well Kaos Kiwi already had the book so being a decent geezer he said give the book to someone else, so after a POLL which came out 50-50 between Wilko and Lordshadow, I decided to give 4th to LORDSHADOW!! 

It was a great comp all the entries were of a very high standard and I just wanna thank everybody who entered!!

The model and textures can be used for freeware, shareware or commercial games etc. A credit to the peoples texture work and maybe a link to 3D Game Resources site would be nice ;-))






What is all this stuff???

fighter1.3ds - Model in 3ds format
fighter1.ms3d - Model in Milkshape format

apply the various jpg skins for variations

uvmap.jpg - the UV layout to be used as a guide for your texture

Upon opening the 3ds model in some programs the skin will be VERY dark, turn up the emissive or luminance to see it properly...


NOTE:- my skin "psionic.jpg" and my brothers skin "thor.jpg" were not entered into the comnpetition for obvious reasons ;-)

http://www.psionic3d.co.uk
Psionic 2005
